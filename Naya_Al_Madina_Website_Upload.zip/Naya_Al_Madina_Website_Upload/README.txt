Naya Al Madina Website
---------------------
Upload this folder to GitHub Pages for live website.
Folder includes:
- index.html
- images/ (product image placeholders)
Instructions:
1. Open GitHub repository.
2. Upload all files here.
3. Your website will be live via GitHub Pages.
